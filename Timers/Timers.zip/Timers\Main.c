#include <p18cxxx.h>
#include <timers.h>
#include "Timers_lib.h"
#include <stdio.h>

#define TRUE 0x01
#define LED_PIN TRISAbits.TRISA0
#define LED PORTAbits.RA0

//==================prototyping funtions
void Timer0_start();
void Timer0_Init();
void Timer0_reset();
//==============================
	
		
			
				
void main(void){
	LED_PIN = 0x00;
	Timer0_Init();
	
	while(TRUE){
		Timer0_start(500);
		LED = 0x01;
		Timer0_reset();
		Timer0_start(500);
		LED = 0x00;
		Timer0_reset();
		
	}
}


